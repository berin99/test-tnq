<!DOCTYPE html>
<html>
<head>
    <title>Book Records</title>
</head>
<body>
    <h1>PHP: Creating a application to store and retrieve data</h1>
    <a href="create-book-record.php"><button>Add New Book</button></a>
    <a href="show-books.php"><button>Books List</button></a>
</body>
</html>